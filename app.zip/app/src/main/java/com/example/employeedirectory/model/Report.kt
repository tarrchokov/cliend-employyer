package com.example.employeedirectory.model

import java.util.Date

data class Report(
    val id: String = "",
    val title: String = "",
    val type: ReportType = ReportType.GENERAL,
    val content: String = "",
    val createdAt: Date = Date(),
    val createdBy: String = "",
    val parameters: Map<String, String> = emptyMap()
)

enum class ReportType {
    GENERAL,
    DEPARTMENT,
    POSITION,
    STATISTICS,
    EXPORT
}

data class ReportRequest(
    val type: String,
    val title: String,
    val parameters: Map<String, String> = emptyMap()
)

data class ReportResponse(
    val id: String,
    val title: String,
    val content: String,
    val createdAt: String,
    val downloadUrl: String? = null
)

data class ReportStatistics(
    val totalEmployees: Int,
    val totalDepartments: Int,
    val totalPositions: Int,
    val departmentBreakdown: Map<String, Int>,
    val positionBreakdown: Map<String, Int>,
    val averageEmployeesPerDepartment: Double,
    val largestDepartment: String,
    val mostPopularPosition: String
)
