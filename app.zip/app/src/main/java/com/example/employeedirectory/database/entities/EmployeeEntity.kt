package com.example.employeedirectory.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class EmployeeEntity(
    @PrimaryKey
    val id: String,
    val firstName: String,
    val lastName: String,
    val position: String,
    val department: String,
    val email: String
)
