package com.example.employeedirectory.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val type: String,
    val content: String,
    val createdAt: Long,
    val createdBy: String,
    val downloadUrl: String
)
