package com.example.employeedirectory.utils

import android.content.Context
import android.content.SharedPreferences

object RoleUtils {
    const val ADMIN_ROLE = "Admin"
    const val USER_ROLE = "User"
    
    private fun getSharedPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
    }
    
    fun isAdmin(context: Context): Boolean {
        return getSharedPreferences(context).getString("user_role", "") == ADMIN_ROLE
    }
    
    fun isUser(context: Context): Boolean {
        return getSharedPreferences(context).getString("user_role", "") == USER_ROLE
    }
    
    fun hasAdminAccess(context: Context): Boolean {
        return isAdmin(context)
    }
    
    fun canEditEmployees(context: Context): Boolean {
        return isAdmin(context)
    }
    
    fun canDeleteEmployees(context: Context): Boolean {
        return isAdmin(context)
    }
    
    fun canCreateReports(context: Context): Boolean {
        return true
    }
    
    fun canViewStatistics(context: Context): Boolean {
        return true
    }
    
    fun getCurrentUser(context: Context): String? {
        return getSharedPreferences(context).getString("current_user", null)
    }
    
    fun isLoggedIn(context: Context): Boolean {
        return getSharedPreferences(context).getBoolean("is_logged_in", false)
    }
}
