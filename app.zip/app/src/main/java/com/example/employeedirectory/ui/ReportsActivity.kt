package com.example.employeedirectory.ui

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.employeedirectory.R
import com.example.employeedirectory.databinding.ActivityReportsBinding
import com.example.employeedirectory.databinding.DialogCreateReportBinding
import com.example.employeedirectory.model.Employee
import com.example.employeedirectory.model.ReportRequest
import com.example.employeedirectory.model.ReportResponse
import com.example.employeedirectory.model.ReportType
import com.example.employeedirectory.repository.LocalRepository
import com.example.employeedirectory.utils.RoleUtils
import com.example.employeedirectory.ui.adapter.ReportAdapter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class ReportsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReportsBinding
    private lateinit var reportAdapter: ReportAdapter
    private lateinit var repository: LocalRepository
    private var allReports: List<ReportResponse> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = LocalRepository(this)
        setupToolbar()
        setupRecyclerView()
        setupButtons()
        loadReports()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        reportAdapter = ReportAdapter(
            reports = emptyList(),
            onViewClick = { report -> viewReport(report) },
            onDeleteClick = { report -> 
                if (RoleUtils.canDeleteEmployees(this)) {
                    showDeleteConfirmation(report)
                } else {
                    Toast.makeText(this, getString(R.string.error_access_denied), Toast.LENGTH_SHORT).show()
                }
            },
            onDownloadClick = { report -> downloadReport(report) },
            canDelete = RoleUtils.canDeleteEmployees(this)
        )
        
        binding.recyclerViewReports.apply {
            layoutManager = LinearLayoutManager(this@ReportsActivity)
            adapter = reportAdapter
        }
    }

    private fun setupButtons() {
        if (RoleUtils.canCreateReports(this)) {
            binding.fabCreateReport.setOnClickListener {
                showCreateReportDialog()
            }
        } else {
            binding.fabCreateReport.visibility = android.view.View.GONE
        }

        binding.buttonRefresh.setOnClickListener {
            loadReports()
        }
    }

    private fun loadReports() {
        showProgress(true)
        lifecycleScope.launch(Dispatchers.Main) {
            try {
                // Простая загрузка отчетов
                val reports = repository.getAllReportsSync()
                allReports = reports
                reportAdapter.updateReports(reports)
                showProgress(false)
                
                // Если отчетов нет, создаем тестовый
                if (reports.isEmpty()) {
                    createTestReport()
                }
            } catch (e: Exception) {
                showProgress(false)
                android.util.Log.e("ReportsActivity", "Error loading reports: ${e.message}", e)
                // Показываем пустой список вместо ошибки
                allReports = emptyList()
                reportAdapter.updateReports(emptyList())
                Toast.makeText(this@ReportsActivity, "Отчеты не найдены. Создайте новый отчет.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun createTestReport() {
        lifecycleScope.launch(Dispatchers.Main) {
            try {
                val testReport = repository.createReport("general", "Добро пожаловать!")
                Toast.makeText(this@ReportsActivity, "Создан тестовый отчет", Toast.LENGTH_SHORT).show()
                loadReports() // Перезагружаем список
            } catch (e: Exception) {
                android.util.Log.e("ReportsActivity", "Error creating test report: ${e.message}", e)
            }
        }
    }

    private fun showCreateReportDialog() {
        val dialogBinding = DialogCreateReportBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Создать отчет")
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        val reportTypes = ReportType.values().map { it.name }
        val adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, reportTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dialogBinding.spinnerReportType.adapter = adapter

        dialogBinding.buttonCreate.setOnClickListener {
            val title = dialogBinding.editTextTitle.text.toString().trim()
            val selectedType = ReportType.values()[dialogBinding.spinnerReportType.selectedItemPosition]
            
            if (title.isBlank()) {
                Toast.makeText(this, "Введите название отчета", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            createReport(ReportRequest(selectedType.name, title))
            dialog.dismiss()
        }

        dialogBinding.buttonCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun createReport(request: ReportRequest) {
        showProgress(true)
        lifecycleScope.launch(Dispatchers.Main) {
            try {
                val response = repository.createReport(request.type, request.title)
                
                showProgress(false)
                Toast.makeText(this@ReportsActivity, "Отчет создан: ${response.title}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                showProgress(false)
                android.util.Log.e("ReportsActivity", "Error creating report: ${e.message}", e)
                Toast.makeText(this@ReportsActivity, "Ошибка создания отчета: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun viewReport(report: ReportResponse) {
        val dialog = AlertDialog.Builder(this)
            .setTitle(report.title)
            .setMessage(report.content)
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    private fun showDeleteConfirmation(report: ReportResponse) {
        AlertDialog.Builder(this)
            .setTitle("Удаление отчета")
            .setMessage("Вы уверены, что хотите удалить отчет \"${report.title}\"?")
            .setPositiveButton("Удалить") { _, _ ->
                deleteReport(report.id)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteReport(reportId: String) {
        showProgress(true)
        lifecycleScope.launch(Dispatchers.Main) {
            try {
                val success = repository.deleteReport(reportId)
                
                showProgress(false)
                if (success) {
                    Toast.makeText(this@ReportsActivity, "Отчет удален", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@ReportsActivity, "Ошибка удаления отчета", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                showProgress(false)
                android.util.Log.e("ReportsActivity", "Error deleting report: ${e.message}", e)
                Toast.makeText(this@ReportsActivity, "Ошибка удаления отчета: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun downloadReport(report: ReportResponse) {
        try {
            // Простое скачивание - показываем содержимое отчета
            val dialog = AlertDialog.Builder(this)
                .setTitle("Отчет: ${report.title}")
                .setMessage("Содержимое отчета:\n\n${report.content}")
                .setPositiveButton("Поделиться") { _, _ ->
                    shareReportContent(report)
                }
                .setNegativeButton("Закрыть", null)
                .create()
            dialog.show()
        } catch (e: Exception) {
            android.util.Log.e("ReportsActivity", "Error downloading report: ${e.message}", e)
            Toast.makeText(this, "Ошибка скачивания отчета: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun shareReportContent(report: ReportResponse) {
        try {
            val shareText = "ОТЧЕТ: ${report.title}\n" +
                    "Дата создания: ${report.createdAt}\n" +
                    "=".repeat(50) + "\n\n" +
                    report.content
            
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Отчет: ${report.title}")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            
            startActivity(Intent.createChooser(intent, "Поделиться отчетом"))
        } catch (e: Exception) {
            android.util.Log.e("ReportsActivity", "Error sharing report: ${e.message}", e)
            Toast.makeText(this, "Ошибка отправки отчета: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    

    private fun showProgress(show: Boolean) {
        binding.progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }
}
