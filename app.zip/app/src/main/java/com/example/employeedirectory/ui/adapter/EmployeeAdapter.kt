package com.example.employeedirectory.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.employeedirectory.databinding.ItemEmployeeBinding
import com.example.employeedirectory.model.Employee

class EmployeeAdapter(
    private var employees: List<Employee>,
    private val onEditClick: (Employee) -> Unit,
    private val onDeleteClick: (Employee) -> Unit,
    private val canEdit: Boolean = true,
    private val canDelete: Boolean = true
) : RecyclerView.Adapter<EmployeeAdapter.EmployeeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmployeeViewHolder {
        val binding = ItemEmployeeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EmployeeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EmployeeViewHolder, position: Int) {
        holder.bind(employees[position])
    }

    override fun getItemCount(): Int = employees.size

    fun updateEmployees(newEmployees: List<Employee>) {
        employees = newEmployees
        notifyDataSetChanged()
    }

    inner class EmployeeViewHolder(
        private val binding: ItemEmployeeBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(employee: Employee) {
            binding.textViewName.text = employee.fullName
            binding.textViewPosition.text = employee.position
            binding.textViewDepartment.text = employee.department
            binding.textViewEmail.text = employee.email
            binding.textViewPhone.text = employee.phone

            binding.buttonEdit.visibility = if (canEdit) View.VISIBLE else View.GONE
            binding.buttonDelete.visibility = if (canDelete) View.VISIBLE else View.GONE

            binding.buttonEdit.setOnClickListener {
                if (canEdit) {
                    onEditClick(employee)
                }
            }

            binding.buttonDelete.setOnClickListener {
                if (canDelete) {
                    onDeleteClick(employee)
                }
            }
        }
    }
}
