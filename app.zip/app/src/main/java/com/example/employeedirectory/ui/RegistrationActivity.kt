package com.example.employeedirectory.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.employeedirectory.R
import com.example.employeedirectory.databinding.ActivityRegistrationBinding
import com.example.employeedirectory.repository.LocalRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RegistrationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegistrationBinding
    private lateinit var repository: LocalRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = LocalRepository(this)
        setupButtons()
    }

    private fun setupButtons() {
        binding.buttonRegister.setOnClickListener {
            registerUser()
        }

        binding.buttonBackToLogin.setOnClickListener {
            finish()
        }
    }

    private fun registerUser() {
        val username = binding.editUsername.text.toString().trim()
        val password = binding.editPassword.text.toString().trim()
        val confirmPassword = binding.editConfirmPassword.text.toString().trim()

        if (username.isBlank()) {
            Toast.makeText(this, getString(R.string.error_username_required), Toast.LENGTH_SHORT).show()
            return
        }

        if (password.isBlank()) {
            Toast.makeText(this, getString(R.string.error_password_required), Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(this, getString(R.string.error_password_too_short), Toast.LENGTH_SHORT).show()
            return
        }

        if (password != confirmPassword) {
            Toast.makeText(this, getString(R.string.error_passwords_dont_match), Toast.LENGTH_SHORT).show()
            return
        }

        showProgress(true)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val success = repository.registerUser(username, password)
                
                withContext(Dispatchers.Main) {
                    showProgress(false)
                    if (success) {
                        Toast.makeText(this@RegistrationActivity, getString(R.string.success_registration), Toast.LENGTH_SHORT).show()
                        
                        val intent = Intent(this@RegistrationActivity, LoginActivity::class.java)
                        intent.putExtra("username", username)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@RegistrationActivity, getString(R.string.error_user_exists), Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showProgress(false)
                    Toast.makeText(this@RegistrationActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showProgress(show: Boolean) {
        binding.progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
        binding.buttonRegister.isEnabled = !show
        binding.buttonBackToLogin.isEnabled = !show
    }
}
