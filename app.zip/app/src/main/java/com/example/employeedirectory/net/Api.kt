package com.example.employeedirectory.net

import com.example.employeedirectory.BuildConfig
import com.example.employeedirectory.model.EmployeeCreateRequest
import com.example.employeedirectory.model.EmployeeDto
import com.example.employeedirectory.model.EmployeeUpdateRequest
import com.example.employeedirectory.model.ReportRequest
import com.example.employeedirectory.model.ReportResponse
import com.example.employeedirectory.model.ReportStatistics
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

data class LoginResponse(val token: String, val role: String)
data class RegisterRequest(val userName: String, val password: String)

interface ApiService {
    @POST("/api/auth/login")
    suspend fun login(@Body body: Map<String, String>): LoginResponse

    @POST("/api/auth/register")
    suspend fun register(@Body request: RegisterRequest)

    @GET("/api/employees")
    suspend fun getEmployees(): List<EmployeeDto>

    @POST("/api/employees")
    suspend fun createEmployee(@Body employee: EmployeeCreateRequest): EmployeeDto

    @PUT("/api/employees/{id}")
    suspend fun updateEmployee(@Path("id") id: String, @Body employee: EmployeeUpdateRequest)

    @DELETE("/api/employees/{id}")
    suspend fun deleteEmployee(@Path("id") id: String)

    @GET("/api/reports/statistics")
    suspend fun getReportStatistics(): ReportStatistics

    @POST("/api/reports")
    suspend fun createReport(@Body request: ReportRequest): ReportResponse

    @GET("/api/reports")
    suspend fun getReports(): List<ReportResponse>

    @GET("/api/reports/{id}")
    suspend fun getReport(@Path("id") id: String): ReportResponse

    @DELETE("/api/reports/{id}")
    suspend fun deleteReport(@Path("id") id: String)
}

object Api {
    var token: String? = null
    var userRole: String? = null

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val builder = original.newBuilder()
        token?.let { builder.addHeader("Authorization", "Bearer $it") }
        chain.proceed(builder.build())
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
            .addInterceptor(authInterceptor)
            .build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(if (BuildConfig.STANDALONE_MODE) "http://localhost" else BuildConfig.API_BASE)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
    }

    val service: ApiService by lazy { retrofit.create(ApiService::class.java) }
    
    // Проверка на standalone режим
    fun isStandaloneMode(): Boolean = BuildConfig.STANDALONE_MODE
}

