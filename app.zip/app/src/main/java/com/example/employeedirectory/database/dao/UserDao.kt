package com.example.employeedirectory.database.dao

import androidx.room.*
import com.example.employeedirectory.database.entities.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE userName = :userName")
    suspend fun getUserByUserName(userName: String): UserEntity?

    @Query("SELECT * FROM users WHERE userName = :userName AND passwordHash = :passwordHash")
    suspend fun authenticateUser(userName: String, passwordHash: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("SELECT COUNT(*) FROM users WHERE userName = :userName")
    suspend fun userExists(userName: String): Int

    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
}
