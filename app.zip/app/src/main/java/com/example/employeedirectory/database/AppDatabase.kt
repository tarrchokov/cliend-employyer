package com.example.employeedirectory.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.example.employeedirectory.database.dao.EmployeeDao
import com.example.employeedirectory.database.dao.ReportDao
import com.example.employeedirectory.database.dao.UserDao
import com.example.employeedirectory.database.entities.EmployeeEntity
import com.example.employeedirectory.database.entities.ReportEntity
import com.example.employeedirectory.database.entities.UserEntity
import kotlinx.coroutines.flow.first
import java.util.UUID

@Database(
    entities = [UserEntity::class, EmployeeEntity::class, ReportEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun reportDao(): ReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "employee_directory_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun initializeWithDefaultData(database: AppDatabase) {
            try {
                val userDao = database.userDao()
                val reportDao = database.reportDao()
                
                // Проверяем, есть ли уже пользователи
                if (userDao.userExists("admin") == 0) {
                    // Создаем админа по умолчанию
                    val adminUser = UserEntity(
                        id = UUID.randomUUID().toString(),
                        userName = "admin",
                        passwordHash = "admin123", // В реальном приложении нужно хешировать
                        role = "Admin"
                    )
                    userDao.insertUser(adminUser)
                }
                
                // Проверяем, есть ли уже отчеты
                val existingReports = reportDao.getAllReports().first()
                if (existingReports.isEmpty()) {
                    // Создаем тестовый отчет
                    val testReport = com.example.employeedirectory.database.entities.ReportEntity(
                        id = UUID.randomUUID().toString(),
                        title = "Добро пожаловать!",
                        type = "general",
                        content = "Это тестовый отчет. Вы можете создавать новые отчеты, используя кнопку '+' внизу экрана.",
                        createdAt = System.currentTimeMillis(),
                        createdBy = "System",
                        downloadUrl = "local://report/${UUID.randomUUID()}"
                    )
                    reportDao.insertReport(testReport)
                }
            } catch (e: Exception) {
                android.util.Log.e("AppDatabase", "Error initializing default data: ${e.message}", e)
            }
        }
    }
}
