package com.example.employeedirectory.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.employeedirectory.databinding.ActivityStatisticsBinding
import com.example.employeedirectory.model.Employee
import com.example.employeedirectory.repository.LocalRepository
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatisticsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStatisticsBinding
    private lateinit var repository: LocalRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = LocalRepository(this)
        setupToolbar()
        loadStatistics()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadStatistics() {
        showProgress(true)
        lifecycleScope.launch {
            try {
                repository.getAllEmployees().collect { employees ->
                    showProgress(false)
                    displayStatistics(employees)
                }
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@StatisticsActivity, "Ошибка загрузки: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun displayStatistics(employees: List<Employee>) {
        binding.textViewTotalEmployees.text = employees.size.toString()
        
        // Статистика по отделам
        val departmentStats = employees.groupBy { it.department }
            .mapValues { it.value.size }
            .toList()
            .sortedByDescending { it.second }
        
        binding.textViewTotalDepartments.text = departmentStats.size.toString()
        val largestDepartment = departmentStats.firstOrNull()
        if (largestDepartment != null) {
            binding.textViewLargestDepartment.text = "${largestDepartment.first}: ${largestDepartment.second} сотрудников"
        }
        
        // Статистика по должностям
        val positionStats = employees.groupBy { it.position }
            .mapValues { it.value.size }
            .toList()
            .sortedByDescending { it.second }
        
        binding.textViewTotalPositions.text = positionStats.size.toString()
        val mostPopularPosition = positionStats.firstOrNull()
        if (mostPopularPosition != null) {
            binding.textViewMostPopularPosition.text = "${mostPopularPosition.first}: ${mostPopularPosition.second} сотрудников"
        }
        
        val avgAge = employees.size / departmentStats.size.coerceAtLeast(1)
        binding.textViewAvgEmployeesPerDepartment.text = avgAge.toString()
    }

    private fun showProgress(show: Boolean) {
        binding.progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }
}
