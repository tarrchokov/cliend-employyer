package com.example.employeedirectory.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.employeedirectory.databinding.ItemReportBinding
import com.example.employeedirectory.model.ReportResponse
import java.text.SimpleDateFormat
import java.util.*

class ReportAdapter(
    private var reports: List<ReportResponse>,
    private val onViewClick: (ReportResponse) -> Unit,
    private val onDeleteClick: (ReportResponse) -> Unit,
    private val onDownloadClick: (ReportResponse) -> Unit,
    private val canDelete: Boolean = true
) : RecyclerView.Adapter<ReportAdapter.ReportViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReportViewHolder {
        val binding = ItemReportBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ReportViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReportViewHolder, position: Int) {
        holder.bind(reports[position])
    }

    override fun getItemCount(): Int = reports.size

    fun updateReports(newReports: List<ReportResponse>) {
        reports = newReports
        notifyDataSetChanged()
    }

    inner class ReportViewHolder(
        private val binding: ItemReportBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(report: ReportResponse) {
            binding.textViewReportTitle.text = report.title
            
            try {
                val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                val outputFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                val date = inputFormat.parse(report.createdAt)
                binding.textViewReportDate.text = outputFormat.format(date ?: Date())
            } catch (e: Exception) {
                binding.textViewReportDate.text = report.createdAt
            }

            binding.textViewReportPreview.text = if (report.content.length > 100) {
                report.content.substring(0, 100) + "..."
            } else {
                report.content
            }

            binding.buttonView.setOnClickListener {
                onViewClick(report)
            }

            binding.buttonDelete.visibility = if (canDelete) android.view.View.VISIBLE else android.view.View.GONE

            binding.buttonDelete.setOnClickListener {
                if (canDelete) {
                    onDeleteClick(report)
                }
            }

            binding.buttonDownload.setOnClickListener {
                onDownloadClick(report)
            }
        }
    }
}
