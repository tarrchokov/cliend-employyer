package com.example.employeedirectory.repository

import android.content.Context
import com.example.employeedirectory.database.AppDatabase
import com.example.employeedirectory.database.entities.EmployeeEntity
import com.example.employeedirectory.database.entities.ReportEntity
import com.example.employeedirectory.database.entities.UserEntity
import com.example.employeedirectory.model.Employee
import com.example.employeedirectory.model.EmployeeDto
import com.example.employeedirectory.model.Report
import com.example.employeedirectory.model.ReportResponse
import com.example.employeedirectory.model.ReportStatistics
import com.example.employeedirectory.model.ReportType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

class LocalRepository(context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val userDao = database.userDao()
    private val employeeDao = database.employeeDao()
    private val reportDao = database.reportDao()

    init {
        // Инициализируем базу данных с данными по умолчанию
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.initializeWithDefaultData(database)
            } catch (e: Exception) {
                // Логируем ошибку, но не прерываем работу приложения
                android.util.Log.e("LocalRepository", "Error initializing database: ${e.message}")
            }
        }
    }

    // User operations
    suspend fun authenticateUser(userName: String, password: String): UserEntity? {
        return userDao.authenticateUser(userName, password)
    }

    suspend fun registerUser(userName: String, password: String): Boolean {
        return if (userDao.userExists(userName) == 0) {
            val user = UserEntity(
                id = UUID.randomUUID().toString(),
                userName = userName,
                passwordHash = password, // В реальном приложении нужно хешировать
                role = "User"
            )
            userDao.insertUser(user)
            true
        } else {
            false
        }
    }

    // Employee operations
    fun getAllEmployees(): Flow<List<Employee>> {
        return employeeDao.getAllEmployees().map { entities ->
            entities.map { it.toEmployee() }
        }
    }

    suspend fun getEmployeeById(id: String): Employee? {
        return employeeDao.getEmployeeById(id)?.toEmployee()
    }

    suspend fun createEmployee(firstName: String, lastName: String, position: String, department: String, email: String): Employee {
        val employee = EmployeeEntity(
            id = UUID.randomUUID().toString(),
            firstName = firstName,
            lastName = lastName,
            position = position,
            department = department,
            email = email
        )
        employeeDao.insertEmployee(employee)
        return employee.toEmployee()
    }

    suspend fun updateEmployee(id: String, firstName: String, lastName: String, position: String, department: String, email: String): Boolean {
        val existingEmployee = employeeDao.getEmployeeById(id) ?: return false
        val updatedEmployee = existingEmployee.copy(
            firstName = firstName,
            lastName = lastName,
            position = position,
            department = department,
            email = email
        )
        employeeDao.updateEmployee(updatedEmployee)
        return true
    }

    suspend fun deleteEmployee(id: String): Boolean {
        return if (employeeDao.getEmployeeById(id) != null) {
            employeeDao.deleteEmployeeById(id)
            true
        } else {
            false
        }
    }

    // Report operations
    fun getAllReports(): Flow<List<ReportResponse>> {
        return reportDao.getAllReports().map { entities ->
            entities.map { it.toReportResponse() }
        }
    }
    
    suspend fun getAllReportsSync(): List<ReportResponse> {
        return try {
            val entities = reportDao.getAllReportsSync()
            entities.map { it.toReportResponse() }
        } catch (e: Exception) {
            android.util.Log.e("LocalRepository", "Error getting reports sync: ${e.message}", e)
            // Возвращаем пустой список вместо ошибки
            emptyList()
        }
    }

    suspend fun createReport(type: String, title: String): ReportResponse {
        return try {
            // Простое создание отчета
            val content = when (type.lowercase()) {
                "general" -> "Общий отчет: $title\nДата создания: ${java.util.Date()}\nВсего сотрудников: ${employeeDao.getAllEmployeesSync().size}"
                "department" -> "Отчет по отделам: $title\nДата создания: ${java.util.Date()}"
                "position" -> "Отчет по должностям: $title\nДата создания: ${java.util.Date()}"
                "statistics" -> "Статистический отчет: $title\nДата создания: ${java.util.Date()}"
                "export" -> "Экспорт данных: $title\nДата создания: ${java.util.Date()}"
                else -> "Отчет: $title\nДата создания: ${java.util.Date()}\nТип: $type"
            }
            
            val report = ReportEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                type = type,
                content = content,
                createdAt = System.currentTimeMillis(),
                createdBy = "System",
                downloadUrl = "local://report/${UUID.randomUUID()}"
            )
            reportDao.insertReport(report)
            report.toReportResponse()
        } catch (e: Exception) {
            android.util.Log.e("LocalRepository", "Error creating report: ${e.message}", e)
            // Возвращаем простой отчет в случае ошибки
            val fallbackReport = ReportEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                type = type,
                content = "Отчет создан: $title\nДата: ${java.util.Date()}\nТип: $type",
                createdAt = System.currentTimeMillis(),
                createdBy = "System",
                downloadUrl = "local://report/${UUID.randomUUID()}"
            )
            reportDao.insertReport(fallbackReport)
            fallbackReport.toReportResponse()
        }
    }

    suspend fun getReportStatistics(): ReportStatistics {
        val employeesList = employeeDao.getAllEmployees().first()
        val employees = employeesList.map { it.toEmployee() }
        return generateStatistics(employees)
    }

    suspend fun deleteReport(id: String): Boolean {
        return if (reportDao.getReportById(id) != null) {
            reportDao.deleteReportById(id)
            true
        } else {
            false
        }
    }

    // Helper functions
    private fun EmployeeEntity.toEmployee(): Employee {
        return Employee(
            id = this.id,
            fullName = "$firstName $lastName",
            position = this.position,
            department = this.department,
            phone = "Не указан",
            email = this.email,
            hireDate = Date(),
            isDeleted = false
        )
    }

    private fun ReportEntity.toReportResponse(): ReportResponse {
        return ReportResponse(
            id = this.id,
            title = this.title,
            content = this.content,
            createdAt = Date(this.createdAt).toString(),
            downloadUrl = this.downloadUrl
        )
    }

    private fun generateReportContent(type: String, employees: List<Employee>): String {
        return when (type.lowercase()) {
            "general" -> generateGeneralReport(employees)
            "department" -> generateDepartmentReport(employees)
            "position" -> generatePositionReport(employees)
            "statistics" -> generateStatisticsReport(employees)
            "export" -> generateExportReport(employees)
            else -> "Неизвестный тип отчета"
        }
    }

    private fun generateGeneralReport(employees: List<Employee>): String {
        return "ОБЩИЙ ОТЧЕТ ПО СОТРУДНИКАМ\n\n" +
                "Всего сотрудников: ${employees.size}\n" +
                "Дата создания: ${Date()}\n\n" +
                "СПИСОК СОТРУДНИКОВ:\n" +
                employees.mapIndexed { index, employee -> 
                    "${index + 1}. ${employee.fullName} - ${employee.department} - ${employee.email}" 
                }.joinToString("\n")
    }

    private fun generateDepartmentReport(employees: List<Employee>): String {
        val departments = employees.groupBy { it.department }.toList().sortedByDescending { it.second.size }
        return "ОТЧЕТ ПО ОТДЕЛАМ\n\n" +
                "Дата создания: ${Date()}\n\n" +
                "СТАТИСТИКА ПО ОТДЕЛАМ:\n" +
                departments.joinToString("\n") { "${it.first}: ${it.second.size} сотрудников" }
    }

    private fun generatePositionReport(employees: List<Employee>): String {
        return "ОТЧЕТ ПО ДОЛЖНОСТЯМ\n\n" +
                "Дата создания: ${Date()}\n\n" +
                "Всего сотрудников: ${employees.size}\n" +
                "Уникальных должностей: ${employees.map { it.position }.distinct().size}"
    }

    private fun generateStatisticsReport(employees: List<Employee>): String {
        val departments = employees.groupBy { it.department }
        return "СТАТИСТИЧЕСКИЙ ОТЧЕТ\n\n" +
                "Дата создания: ${Date()}\n\n" +
                "ОБЩАЯ СТАТИСТИКА:\n" +
                "• Всего сотрудников: ${employees.size}\n" +
                "• Количество отделов: ${departments.size}\n" +
                "• Среднее количество сотрудников на отдел: ${if (departments.isNotEmpty()) employees.size.toDouble() / departments.size else 0.0}\n\n" +
                "ПО ОТДЕЛАМ:\n" +
                departments.toList().sortedByDescending { it.second.size }.joinToString("\n") { 
                    "• ${it.first}: ${it.second.size} сотрудников" 
                }
    }

    private fun generateExportReport(employees: List<Employee>): String {
        return "ЭКСПОРТ ДАННЫХ\n\n" +
                "Дата создания: ${Date()}\n\n" +
                "Экспортировано ${employees.size} записей сотрудников.\n" +
                "Формат: CSV\n" +
                "Кодировка: UTF-8"
    }

    private fun generateStatistics(employees: List<Employee>): ReportStatistics {
        val departments = employees.groupBy { it.department }
        val positions = employees.groupBy { it.position }
        
        val largestDepartment = departments.maxByOrNull { it.value.size }?.key ?: "Не определен"
        val mostPopularPosition = positions.maxByOrNull { it.value.size }?.key ?: "Не определена"
        
        return ReportStatistics(
            totalEmployees = employees.size,
            totalDepartments = departments.size,
            totalPositions = positions.size,
            departmentBreakdown = departments.mapValues { it.value.size },
            positionBreakdown = positions.mapValues { it.value.size },
            averageEmployeesPerDepartment = if (departments.isNotEmpty()) employees.size.toDouble() / departments.size else 0.0,
            largestDepartment = largestDepartment,
            mostPopularPosition = mostPopularPosition
        )
    }
}