package com.example.employeedirectory.model

import java.util.Date

data class Employee(
    val id: String = "",
    val fullName: String = "",
    val position: String = "",
    val department: String = "",
    val phone: String = "",
    val email: String = "",
    val hireDate: Date = Date(),
    val isDeleted: Boolean = false
) {
    fun getShortInfo(): String = "ID: $id, $fullName - $position ($department)"
    
    fun getFullInfo(): String = 
        "ID: $id\n" +
        "ФИО: $fullName\n" +
        "Должность: $position\n" +
        "Отдел: $department\n" +
        "Телефон: $phone\n" +
        "Email: $email\n" +
        "Дата приема: ${hireDate.toString()}"
    
    fun isValid(): Boolean {
        return fullName.isNotBlank() && 
               position.isNotBlank() && 
               department.isNotBlank() &&
               (phone.isBlank() || isValidPhone(phone)) &&
               (email.isBlank() || isValidEmail(email))
    }
    
    private fun isValidPhone(phone: String): Boolean {
        return phone.matches(Regex("^[\\d\\s\\+\\-\\(\\)]+$"))
    }
    
    private fun isValidEmail(email: String): Boolean {
        return email.matches(Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))
    }
}

data class EmployeeDto(
    val id: String,
    val firstName: String,
    val lastName: String,
    val position: String,
    val department: String,
    val email: String
) {
    fun toEmployee(): Employee {
        return Employee(
            id = id,
            fullName = "$firstName $lastName",
            position = position,
            department = department,
            phone = "Не указан",
            email = email
        )
    }
}

data class EmployeeCreateRequest(
    val firstName: String,
    val lastName: String,
    val position: String,
    val department: String,
    val email: String
)

data class EmployeeUpdateRequest(
    val firstName: String,
    val lastName: String,
    val position: String,
    val department: String,
    val email: String
)
