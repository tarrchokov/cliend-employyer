package com.example.employeedirectory.ui

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.employeedirectory.databinding.ActivityEmployeesBinding
import com.example.employeedirectory.databinding.DialogEmployeeFormBinding
import com.example.employeedirectory.model.Employee
import com.example.employeedirectory.model.EmployeeDto
import com.example.employeedirectory.repository.LocalRepository
import com.example.employeedirectory.R
import com.example.employeedirectory.utils.RoleUtils
import com.example.employeedirectory.ui.adapter.EmployeeAdapter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

class EmployeeListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEmployeesBinding
    private lateinit var employeeAdapter: EmployeeAdapter
    private lateinit var repository: LocalRepository
    private var allEmployees: List<Employee> = emptyList()
    private var filteredEmployees: List<Employee> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmployeesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = LocalRepository(this)
        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupButtons()
        loadEmployees()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val roleText = if (RoleUtils.isAdmin(this)) " (${getString(R.string.role_admin)})" else " (${getString(R.string.role_user)})"
        binding.toolbar.title = getString(R.string.employee_directory) + roleText
        
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        employeeAdapter = EmployeeAdapter(
            employees = emptyList(),
            onEditClick = { employee -> 
                if (RoleUtils.canEditEmployees(this)) {
                    showEditEmployeeDialog(employee)
                } else {
                    Toast.makeText(this, getString(R.string.error_access_denied), Toast.LENGTH_SHORT).show()
                }
            },
            onDeleteClick = { employee -> 
                if (RoleUtils.canDeleteEmployees(this)) {
                    showDeleteConfirmation(employee)
                } else {
                    Toast.makeText(this, getString(R.string.error_access_denied), Toast.LENGTH_SHORT).show()
                }
            },
            canEdit = RoleUtils.canEditEmployees(this),
            canDelete = RoleUtils.canDeleteEmployees(this)
        )
        
        binding.recyclerViewEmployees.apply {
            layoutManager = LinearLayoutManager(this@EmployeeListActivity)
            adapter = employeeAdapter
        }
    }

    private fun setupSearch() {
        binding.editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterEmployees(s.toString())
            }
        })
    }

    private fun setupButtons() {
        if (RoleUtils.canEditEmployees(this)) {
            binding.fabAddEmployee.setOnClickListener {
                showAddEmployeeDialog()
            }
        } else {
            binding.fabAddEmployee.visibility = android.view.View.GONE
        }

        binding.buttonFilterDepartment.setOnClickListener {
            showDepartmentFilterDialog()
        }

        binding.buttonSort.setOnClickListener {
            showSortDialog()
        }

        binding.buttonStatistics.setOnClickListener {
            val intent = android.content.Intent(this@EmployeeListActivity, StatisticsActivity::class.java)
            startActivity(intent)
        }

        binding.buttonReports.setOnClickListener {
            val intent = android.content.Intent(this@EmployeeListActivity, ReportsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loadEmployees() {
        showProgress(true)
        lifecycleScope.launch {
            try {
                repository.getAllEmployees().collect { employees ->
                    allEmployees = employees
                    filteredEmployees = employees
                    updateUI()
                    showProgress(false)
                }
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@EmployeeListActivity, "Ошибка загрузки: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateUI() {
        employeeAdapter.updateEmployees(filteredEmployees)
        updateStatistics()
    }

    private fun updateStatistics() {
        binding.textViewTotalCount.text = filteredEmployees.size.toString()
        val departments = filteredEmployees.map { it.department }.distinct()
        binding.textViewDepartmentCount.text = departments.size.toString()
    }

    private fun filterEmployees(query: String) {
        filteredEmployees = if (query.isBlank()) {
            allEmployees
        } else {
            allEmployees.filter { employee ->
                employee.fullName.contains(query, ignoreCase = true) ||
                employee.position.contains(query, ignoreCase = true) ||
                employee.department.contains(query, ignoreCase = true)
            }
        }
        updateUI()
    }

    private fun showAddEmployeeDialog() {
        val dialogBinding = DialogEmployeeFormBinding.inflate(LayoutInflater.from(this))
        val dialog = AlertDialog.Builder(this)
            .setTitle("Добавить сотрудника")
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        dialogBinding.buttonSave.setOnClickListener {
            val employee = createEmployeeFromForm(dialogBinding)
            if (employee != null) {
                addEmployee(employee)
                dialog.dismiss()
            }
        }

        dialogBinding.buttonCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showEditEmployeeDialog(employee: Employee) {
        val dialogBinding = DialogEmployeeFormBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editTextFullName.setText(employee.fullName)
        dialogBinding.editTextPosition.setText(employee.position)
        dialogBinding.editTextDepartment.setText(employee.department)
        dialogBinding.editTextPhone.setText(employee.phone)
        dialogBinding.editTextEmail.setText(employee.email)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Редактировать сотрудника")
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        dialogBinding.buttonSave.setOnClickListener {
            val updatedEmployee = createEmployeeFromForm(dialogBinding)
            if (updatedEmployee != null) {
                updateEmployee(employee.id, updatedEmployee)
                dialog.dismiss()
            }
        }

        dialogBinding.buttonCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun createEmployeeFromForm(binding: DialogEmployeeFormBinding): Employee? {
        val fullName = binding.editTextFullName.text.toString().trim()
        val position = binding.editTextPosition.text.toString().trim()
        val department = binding.editTextDepartment.text.toString().trim()
        val phone = binding.editTextPhone.text.toString().trim()
        val email = binding.editTextEmail.text.toString().trim()

        if (fullName.isBlank()) {
            Toast.makeText(this, "ФИО не может быть пустым", Toast.LENGTH_SHORT).show()
            return null
        }

        if (position.isBlank()) {
            Toast.makeText(this, "Должность не может быть пустой", Toast.LENGTH_SHORT).show()
            return null
        }

        if (department.isBlank()) {
            Toast.makeText(this, "Отдел не может быть пустым", Toast.LENGTH_SHORT).show()
            return null
        }

        return Employee(
            fullName = fullName,
            position = position,
            department = department,
            phone = phone,
            email = email,
            hireDate = Date()
        )
    }

    private fun addEmployee(employee: Employee) {
        showProgress(true)
        lifecycleScope.launch {
            try {
                val nameParts = employee.fullName.split(" ")
                val firstName = nameParts.firstOrNull() ?: ""
                val lastName = nameParts.drop(1).joinToString(" ")
                
                repository.createEmployee(firstName, lastName, employee.position, employee.department, employee.email)
                
                showProgress(false)
                Toast.makeText(this@EmployeeListActivity, "Сотрудник добавлен", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@EmployeeListActivity, "Ошибка добавления: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateEmployee(employeeId: String, updatedEmployee: Employee) {
        showProgress(true)
        lifecycleScope.launch {
            try {
                val nameParts = updatedEmployee.fullName.split(" ")
                val firstName = nameParts.firstOrNull() ?: ""
                val lastName = nameParts.drop(1).joinToString(" ")
                
                val success = repository.updateEmployee(employeeId, firstName, lastName, updatedEmployee.position, updatedEmployee.department, updatedEmployee.email)
                
                showProgress(false)
                if (success) {
                    Toast.makeText(this@EmployeeListActivity, "Сотрудник обновлен", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@EmployeeListActivity, "Ошибка обновления", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@EmployeeListActivity, "Ошибка обновления: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDeleteConfirmation(employee: Employee) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Удаление сотрудника")
            .setMessage("Вы уверены, что хотите удалить сотрудника?\n\n" +
                    "ФИО: ${employee.fullName}\n" +
                    "Должность: ${employee.position}\n" +
                    "Отдел: ${employee.department}\n\n" +
                    "Это действие нельзя отменить!")
            .setPositiveButton("Удалить") { _, _ ->
                deleteEmployee(employee.id)
            }
            .setNegativeButton("Отмена", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .create()
        dialog.show()
    }

    private fun deleteEmployee(employeeId: String) {
        showProgress(true)
        lifecycleScope.launch {
            try {
                val success = repository.deleteEmployee(employeeId)
                
                showProgress(false)
                if (success) {
                    Toast.makeText(this@EmployeeListActivity, "Сотрудник удален", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@EmployeeListActivity, "Ошибка удаления", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@EmployeeListActivity, "Ошибка удаления: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDepartmentFilterDialog() {
        val departments = allEmployees.map { it.department }.distinct().sorted()
        
        AlertDialog.Builder(this)
            .setTitle("Фильтр по отделу")
            .setItems(departments.toTypedArray()) { _, which ->
                val selectedDepartment = departments[which]
                filteredEmployees = allEmployees.filter { it.department == selectedDepartment }
                updateUI()
            }
            .setNeutralButton("Показать все") { _, _ ->
                filteredEmployees = allEmployees
                updateUI()
            }
            .show()
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf("По имени", "По должности", "По отделу")
        
        AlertDialog.Builder(this)
            .setTitle("Сортировка")
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> filteredEmployees = filteredEmployees.sortedBy { it.fullName }
                    1 -> filteredEmployees = filteredEmployees.sortedBy { it.position }
                    2 -> filteredEmployees = filteredEmployees.sortedBy { it.department }
                }
                updateUI()
            }
            .show()
    }

    private fun showProgress(show: Boolean) {
        binding.progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }
}

