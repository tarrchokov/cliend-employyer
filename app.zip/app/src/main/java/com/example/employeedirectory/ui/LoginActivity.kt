package com.example.employeedirectory.ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.employeedirectory.databinding.ActivityLoginBinding
import com.example.employeedirectory.R
import com.example.employeedirectory.repository.LocalRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var repository: LocalRepository
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = LocalRepository(this)
        sharedPreferences = getSharedPreferences("auth_prefs", MODE_PRIVATE)

        val username = intent.getStringExtra("username")
        if (!username.isNullOrBlank()) {
            binding.editUsername.setText(username)
        }

        setupButtons()
    }

    private fun setupButtons() {
        binding.buttonLogin.setOnClickListener {
            loginUser()
        }

        binding.buttonRegister.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loginUser() {
        val user = binding.editUsername.text.toString()
        val pass = binding.editPassword.text.toString()
        
        if (user.isBlank() || pass.isBlank()) {
            Toast.makeText(this, getString(R.string.error_validation), Toast.LENGTH_SHORT).show()
            return
        }
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val userEntity = repository.authenticateUser(user, pass)
                
                withContext(Dispatchers.Main) {
                    if (userEntity != null) {
                        // Сохраняем данные пользователя
                        sharedPreferences.edit()
                            .putString("current_user", userEntity.userName)
                            .putString("user_role", userEntity.role)
                            .putBoolean("is_logged_in", true)
                            .apply()
                        
                        Toast.makeText(this@LoginActivity, getString(R.string.success_login), Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@LoginActivity, EmployeeListActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@LoginActivity, getString(R.string.error_login), Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@LoginActivity, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

