plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt")
}

android {
    namespace = "com.example.employeedirectory"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.employeedirectory"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField("String", "API_BASE", "\"\"")
            buildConfigField("boolean", "STANDALONE_MODE", "true")
        }
        debug {
            isDebuggable = true
            isMinifyEnabled = false
            buildConfigField("String", "API_BASE", "\"\"")
            buildConfigField("boolean", "STANDALONE_MODE", "true")
            // Используем debug подпись по умолчанию
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    
    configurations.all {
        resolutionStrategy {
            force("androidx.coordinatorlayout:coordinatorlayout:1.2.0")
        }
    }
}

kotlin {
    jvmToolchain(17)
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    
    // Room database
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    
    // SharedPreferences for auth
    implementation("androidx.preference:preference-ktx:1.2.1")
}

configurations.matching { it.name.endsWith("RuntimeClasspathCopy") }.configureEach {
    isCanBeConsumed = false
    isCanBeResolved = false
}

abstract class StartDockerTask : DefaultTask() {
    @TaskAction
    fun run() {
        try {
            project.exec {
                workingDir = project.rootProject.projectDir.parentFile
                commandLine = listOf("docker", "compose", "up", "-d")
                isIgnoreExitValue = true
            }
        } catch (e: Exception) {
            logger.lifecycle("Docker not available in PATH. Skipping auto start. Start manually: docker compose up -d")
        }
    }
}

tasks.register<StartDockerTask>("startDocker") {
    group = "run"
    description = "Start backend containers via docker compose"
}

tasks.named("preBuild").configure {
    dependsOn("startDocker")
}
